package ntu.hongdta_64130758;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Blogweb64130758Application {

	public static void main(String[] args) {
		SpringApplication.run(Blogweb64130758Application.class, args);
	}

}
