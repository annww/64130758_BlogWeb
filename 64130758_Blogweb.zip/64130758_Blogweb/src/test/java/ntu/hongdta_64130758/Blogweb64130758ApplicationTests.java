package ntu.hongdta_64130758;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Blogweb64130758ApplicationTests {

	@Test
	void contextLoads() {
	}

}
